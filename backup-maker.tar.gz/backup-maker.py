from contextlib import closing
from subprocess import call
import datetime
import tarfile
import os

def make_tarfile(output_filename, source_dir):
	with closing(tarfile.open(output_filename, "w:gz")) as tar:
		tar.add(source_dir)

host='pieroe1'
bkpath = '/root/backups/files/'
fecha = datetime.datetime.now().strftime("%Y-%m-%d")
dbfile = bkpath + 'freeswitch-db-'+ fecha +'.tar.gz'
conffile = bkpath + 'freeswitch-conf-'+ fecha +'.tar.gz'
psdaily = bkpath + fecha + '-daily'
psweekly = bkpath + fecha + '-weekly'

make_tarfile(dbfile, "/usr/local/freeswitch/db/")
make_tarfile(conffile, "/usr/local/freeswitch/conf/")
if os.path.isfile(psweekly):
	call(["rsync", "-aze", "ssh", dbfile, conffile, psdaily, psweekly, "Wolverine:~/backups-clientes/"+ host +"/"])
	call(["rsync", "-aze", "ssh", dbfile, conffile, psdaily, psweekly, "Voice:~/backups-clientes/"+ host +"/"])
else:
	call(["rsync", "-aze", "ssh", dbfile, conffile, psdaily, "Wolverine:~/backups-clientes/"+ host +"/"])
	call(["rsync", "-aze", "ssh", dbfile, conffile, psdaily, "Voice:~/backups-clientes/"+ host +"/"])

